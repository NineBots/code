﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace MyProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 aboutForm = new AboutBox1();
            aboutForm.Show();
        }

        private void гражданствоToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CitizenshipForm citizenshipForm = new CitizenshipForm();
            citizenshipForm.MdiParent = this;
            citizenshipForm.Show();
        }

        private void отделениеУФМСToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mvdForm mvdForm = new mvdForm();
            mvdForm.MdiParent = this;
            mvdForm.Show();
        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WorkerForm workerForm = new WorkerForm();
            workerForm.MdiParent = this;
            workerForm.Show();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }
    }
}

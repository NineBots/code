﻿namespace MyProject
{
    partial class PassportsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label idLabel;
            this.passportsDataSet = new MyProject.PassportsDataSet();
            this.workerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.workerTableAdapter = new MyProject.PassportsDataSetTableAdapters.WorkerTableAdapter();
            this.tableAdapterManager = new MyProject.PassportsDataSetTableAdapters.TableAdapterManager();
            this.idTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fKPassportWorkerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.passportTableAdapter = new MyProject.PassportsDataSetTableAdapters.PassportTableAdapter();
            this.mVDBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mVDTableAdapter = new MyProject.PassportsDataSetTableAdapters.MVDTableAdapter();
            this.genderBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.genderTableAdapter = new MyProject.PassportsDataSetTableAdapters.GenderTableAdapter();
            this.citizenshipBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.citizenshipTableAdapter = new MyProject.PassportsDataSetTableAdapters.CitizenshipTableAdapter();
            this.seriaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fathNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.birthdayDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mVDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.workerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.genderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.citizenshipDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.issueDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            idLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.passportsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPassportWorkerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mVDBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.citizenshipBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // passportsDataSet
            // 
            this.passportsDataSet.DataSetName = "PassportsDataSet";
            this.passportsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // workerBindingSource
            // 
            this.workerBindingSource.DataMember = "Worker";
            this.workerBindingSource.DataSource = this.passportsDataSet;
            // 
            // workerTableAdapter
            // 
            this.workerTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CitizenshipTableAdapter = this.citizenshipTableAdapter;
            this.tableAdapterManager.GenderTableAdapter = this.genderTableAdapter;
            this.tableAdapterManager.MVDTableAdapter = this.mVDTableAdapter;
            this.tableAdapterManager.PassportTableAdapter = this.passportTableAdapter;
            this.tableAdapterManager.UpdateOrder = MyProject.PassportsDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WorkerTableAdapter = this.workerTableAdapter;
            // 
            // idLabel
            // 
            idLabel.AutoSize = true;
            idLabel.Location = new System.Drawing.Point(12, 33);
            idLabel.Name = "idLabel";
            idLabel.Size = new System.Drawing.Size(45, 13);
            idLabel.TabIndex = 1;
            idLabel.Text = "Worker:";
            // 
            // idTextBox
            // 
            this.idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.workerBindingSource, "Id", true));
            this.idTextBox.Location = new System.Drawing.Point(63, 33);
            this.idTextBox.Name = "idTextBox";
            this.idTextBox.Size = new System.Drawing.Size(100, 20);
            this.idTextBox.TabIndex = 2;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.seriaDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.fathNameDataGridViewTextBoxColumn,
            this.birthdayDataGridViewTextBoxColumn,
            this.mVDDataGridViewTextBoxColumn,
            this.workerDataGridViewTextBoxColumn,
            this.genderDataGridViewTextBoxColumn,
            this.citizenshipDataGridViewTextBoxColumn,
            this.issueDateDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.fKPassportWorkerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(63, 89);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1141, 344);
            this.dataGridView1.TabIndex = 3;
            // 
            // fKPassportWorkerBindingSource
            // 
            this.fKPassportWorkerBindingSource.DataMember = "FK_Passport_Worker";
            this.fKPassportWorkerBindingSource.DataSource = this.workerBindingSource;
            // 
            // passportTableAdapter
            // 
            this.passportTableAdapter.ClearBeforeFill = true;
            // 
            // mVDBindingSource
            // 
            this.mVDBindingSource.DataMember = "MVD";
            this.mVDBindingSource.DataSource = this.passportsDataSet;
            // 
            // mVDTableAdapter
            // 
            this.mVDTableAdapter.ClearBeforeFill = true;
            // 
            // genderBindingSource
            // 
            this.genderBindingSource.DataMember = "Gender";
            this.genderBindingSource.DataSource = this.passportsDataSet;
            // 
            // genderTableAdapter
            // 
            this.genderTableAdapter.ClearBeforeFill = true;
            // 
            // citizenshipBindingSource
            // 
            this.citizenshipBindingSource.DataMember = "Citizenship";
            this.citizenshipBindingSource.DataSource = this.passportsDataSet;
            // 
            // citizenshipTableAdapter
            // 
            this.citizenshipTableAdapter.ClearBeforeFill = true;
            // 
            // seriaDataGridViewTextBoxColumn
            // 
            this.seriaDataGridViewTextBoxColumn.DataPropertyName = "Seria";
            this.seriaDataGridViewTextBoxColumn.HeaderText = "Seria";
            this.seriaDataGridViewTextBoxColumn.Name = "seriaDataGridViewTextBoxColumn";
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "Number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "Number";
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Surname";
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            // 
            // fathNameDataGridViewTextBoxColumn
            // 
            this.fathNameDataGridViewTextBoxColumn.DataPropertyName = "FathName";
            this.fathNameDataGridViewTextBoxColumn.HeaderText = "FathName";
            this.fathNameDataGridViewTextBoxColumn.Name = "fathNameDataGridViewTextBoxColumn";
            // 
            // birthdayDataGridViewTextBoxColumn
            // 
            this.birthdayDataGridViewTextBoxColumn.DataPropertyName = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.HeaderText = "Birthday";
            this.birthdayDataGridViewTextBoxColumn.Name = "birthdayDataGridViewTextBoxColumn";
            // 
            // mVDDataGridViewTextBoxColumn
            // 
            this.mVDDataGridViewTextBoxColumn.DataPropertyName = "MVD";
            this.mVDDataGridViewTextBoxColumn.DataSource = this.mVDBindingSource;
            this.mVDDataGridViewTextBoxColumn.DisplayMember = "MVD";
            this.mVDDataGridViewTextBoxColumn.HeaderText = "MVD";
            this.mVDDataGridViewTextBoxColumn.Name = "mVDDataGridViewTextBoxColumn";
            this.mVDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.mVDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.mVDDataGridViewTextBoxColumn.ValueMember = "Id";
            // 
            // workerDataGridViewTextBoxColumn
            // 
            this.workerDataGridViewTextBoxColumn.DataPropertyName = "Worker";
            this.workerDataGridViewTextBoxColumn.HeaderText = "Worker";
            this.workerDataGridViewTextBoxColumn.Name = "workerDataGridViewTextBoxColumn";
            this.workerDataGridViewTextBoxColumn.Visible = false;
            // 
            // genderDataGridViewTextBoxColumn
            // 
            this.genderDataGridViewTextBoxColumn.DataPropertyName = "Gender";
            this.genderDataGridViewTextBoxColumn.DataSource = this.genderBindingSource;
            this.genderDataGridViewTextBoxColumn.DisplayMember = "Gender";
            this.genderDataGridViewTextBoxColumn.HeaderText = "Gender";
            this.genderDataGridViewTextBoxColumn.Name = "genderDataGridViewTextBoxColumn";
            this.genderDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.genderDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.genderDataGridViewTextBoxColumn.ValueMember = "id";
            // 
            // citizenshipDataGridViewTextBoxColumn
            // 
            this.citizenshipDataGridViewTextBoxColumn.DataPropertyName = "Citizenship";
            this.citizenshipDataGridViewTextBoxColumn.DataSource = this.citizenshipBindingSource;
            this.citizenshipDataGridViewTextBoxColumn.DisplayMember = "Citizenship";
            this.citizenshipDataGridViewTextBoxColumn.HeaderText = "Citizenship";
            this.citizenshipDataGridViewTextBoxColumn.Name = "citizenshipDataGridViewTextBoxColumn";
            this.citizenshipDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.citizenshipDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.citizenshipDataGridViewTextBoxColumn.ValueMember = "Id";
            // 
            // issueDateDataGridViewTextBoxColumn
            // 
            this.issueDateDataGridViewTextBoxColumn.DataPropertyName = "Issue_Date";
            this.issueDateDataGridViewTextBoxColumn.HeaderText = "Issue_Date";
            this.issueDateDataGridViewTextBoxColumn.Name = "issueDateDataGridViewTextBoxColumn";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(63, 440);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(170, 60);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(239, 439);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(170, 60);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "Выйти";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // PassportsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1247, 547);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(idLabel);
            this.Controls.Add(this.idTextBox);
            this.Name = "PassportsForm";
            this.Text = "PassportsForm";
            ((System.ComponentModel.ISupportInitialize)(this.passportsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKPassportWorkerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mVDBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.genderBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.citizenshipBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PassportsDataSet passportsDataSet;
        private System.Windows.Forms.BindingSource workerBindingSource;
        private PassportsDataSetTableAdapters.WorkerTableAdapter workerTableAdapter;
        private PassportsDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private PassportsDataSetTableAdapters.PassportTableAdapter passportTableAdapter;
        private System.Windows.Forms.TextBox idTextBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource fKPassportWorkerBindingSource;
        private PassportsDataSetTableAdapters.MVDTableAdapter mVDTableAdapter;
        private System.Windows.Forms.BindingSource mVDBindingSource;
        private PassportsDataSetTableAdapters.GenderTableAdapter genderTableAdapter;
        private System.Windows.Forms.BindingSource genderBindingSource;
        private PassportsDataSetTableAdapters.CitizenshipTableAdapter citizenshipTableAdapter;
        private System.Windows.Forms.BindingSource citizenshipBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn seriaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fathNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn birthdayDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn mVDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn genderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn citizenshipDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn issueDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnExit;
    }
}
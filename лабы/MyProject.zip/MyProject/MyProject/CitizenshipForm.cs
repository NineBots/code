﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProject
{
    public partial class CitizenshipForm : Form
    {
        public CitizenshipForm()
        {
            InitializeComponent();
        }

        private void CitizenshipForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Citizenship". При необходимости она может быть перемещена или удалена.
            this.citizenshipTableAdapter.Fill(this.passportsDataSet.Citizenship);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Citizenship". При необходимости она может быть перемещена или удалена.
            this.citizenshipTableAdapter.Fill(this.passportsDataSet.Citizenship);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            citizenshipTableAdapter.Update(this.passportsDataSet.Citizenship);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

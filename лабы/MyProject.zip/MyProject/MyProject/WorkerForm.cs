﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace MyProject
{
    public partial class WorkerForm : Form
    {
        public WorkerForm()
        {
            InitializeComponent();
        }

        private void WorkerForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);

        }

        private void idLabel_Click(object sender, EventArgs e)
        {

        }


        private void workerDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            PassportsForm passportsForm = new PassportsForm();
            passportsForm.ShowDialog();
            this.workerTableAdapter.Fill(passportsDataSet.Worker);
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            PassportsForm passportsForm = new PassportsForm(workerBindingSource.Position);
            passportsForm.ShowDialog();
            this.workerTableAdapter.Fill(passportsDataSet.Worker);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            PassportsForm passportsForm = new PassportsForm(workerBindingSource.Position);
            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Passports;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand(@"DELETE from Passport WHERE seria in (SELECT seria from Passport inner join worker ON Passport.Worker = worker.id )", conn);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();

            workerBindingSource.RemoveCurrent();
            workerTableAdapter.Update(passportsDataSet.Worker);

        }
    }
}

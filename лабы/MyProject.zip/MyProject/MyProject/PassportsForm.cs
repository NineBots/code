﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProject
{
    public partial class PassportsForm : Form
    {
        public PassportsForm()
        {
            InitializeComponent();
            this.passportTableAdapter.Fill(this.passportsDataSet.Passport);
            this.citizenshipTableAdapter.Fill(this.passportsDataSet.Citizenship);
            this.genderTableAdapter.Fill(this.passportsDataSet.Gender);
            this.mVDTableAdapter.Fill(this.passportsDataSet.MVD);
            workerBindingSource.AddNew();
        }

        public PassportsForm(int index)
        {
            InitializeComponent();
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);
            this.passportTableAdapter.Fill(this.passportsDataSet.Passport);
            this.citizenshipTableAdapter.Fill(this.passportsDataSet.Citizenship);
            this.genderTableAdapter.Fill(this.passportsDataSet.Gender);
            this.mVDTableAdapter.Fill(this.passportsDataSet.MVD);

            workerBindingSource.Position = index;
        }


        private void PassportsForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Citizenship". При необходимости она может быть перемещена или удалена.
            this.citizenshipTableAdapter.Fill(this.passportsDataSet.Citizenship);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Gender". При необходимости она может быть перемещена или удалена.
            this.genderTableAdapter.Fill(this.passportsDataSet.Gender);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.MVD". При необходимости она может быть перемещена или удалена.
            this.mVDTableAdapter.Fill(this.passportsDataSet.MVD);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Passport". При необходимости она может быть перемещена или удалена.
            this.passportTableAdapter.Fill(this.passportsDataSet.Passport);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.Worker". При необходимости она может быть перемещена или удалена.
            this.workerTableAdapter.Fill(this.passportsDataSet.Worker);

        }

   
        private void btnSave_Click(object sender, EventArgs e)
        {
            workerBindingSource.EndEdit();
            workerTableAdapter.Update(passportsDataSet.Worker);
            passportTableAdapter.Update(passportsDataSet.Passport);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

﻿namespace MyProject
{


    partial class PassportsDataSet
    {
    }
}

namespace MyProject.PassportsDataSetTableAdapters
{
    partial class CitizenshipTableAdapter
    {
    }

    public partial class GenderTableAdapter {
    }
}

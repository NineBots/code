﻿using System;
using System.Windows.Forms;

namespace MyProject
{
    public partial class mvdForm : Form
    {
        public mvdForm()
        {
            InitializeComponent();
        }

        private void mvdForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.MVD". При необходимости она может быть перемещена или удалена.
            this.mVDTableAdapter.Fill(this.passportsDataSet.MVD);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "passportsDataSet.MVD". При необходимости она может быть перемещена или удалена.
            this.mVDTableAdapter.Fill(this.passportsDataSet.MVD);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "индивидуальный_проектDataSet.Отделение_УФМС". При необходимости она может быть перемещена или удалена.

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            mVDTableAdapter.Update(this.passportsDataSet.MVD);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
